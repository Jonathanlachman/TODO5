public class Main
{
    public static void main(String[] args)
    {
        JewelryStore store = new JewelryStore();
        store.addItemToCart("Necklace");
        store.addItemToCart("Ring");
        store.addItemToCart("Earrings");

        store.printNumberOfItemsInCart();
    }
}