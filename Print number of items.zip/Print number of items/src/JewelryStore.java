import java.util.ArrayList;
public class JewelryStore
{
    private final ArrayList<String> shoppingCart;
    public JewelryStore()
    {
        this.shoppingCart = new ArrayList<>();
    }
    public void addItemToCart(String item)
    {
        this.shoppingCart.add(item);
    }
    public void removeItemFromCart(String item)
    {
        this.shoppingCart.remove(item);
    }
    public void printNumberOfItemsInCart()
    {
        System.out.println("Number of items in the shopping cart: " + this.shoppingCart.size());
    }
}
